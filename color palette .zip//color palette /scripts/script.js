 const select = document.querySelector(".select");
 const gradientColor = document.querySelectorAll(".color");
 let gradientBox = document.querySelector(".gradient-color");
 let color1 = document.querySelector(".one");
 let color2 = document.querySelector(".two");
  let text = document.querySelector(".text");
 let copy = document.querySelector(".copy");
 let refresh = document.querySelector(".refresh");
 //copy button
     copy.onclick = ()=>{
     let texts = document.querySelector(".text");
     console.log(texts.value);
       texts.select();
        document.execCommand("copy");
        copy.innerText = "Code copied";
        setTimeout(()=>{
        copy.innerText = "Copy color code";},1600);
 
 }
 const ref = ()=>{
     let refs = Math.floor(Math.random() * 0xffffff).toString(16);
     console.log(`#${refs}`);
   return `#${refs}`;
 }
 //gradient generator
 const generateGradient = (isTrue) =>{
     if(isTrue){
       color1.value = ref();
       color2.value = ref();  
     }
const gradient = `linear-gradient(${select.value}, ${color1.value}, ${color2.value})`;
gradientBox.style.background = gradient;
text.value = `background: linear-gradient(${select.value}, ${color1.value}, ${color2.value});`; 
    console.log(gradient); 
 }
 //iterating through gradientColor
 gradientColor.forEach(input =>{
     input.addEventListener("input", () => generateGradient(false));
 });
 //direction change
 select.addEventListener("change",()=> generateGradient(false));
 //refresh btn
 refresh.addEventListener("click", () => generateGradient(true));
